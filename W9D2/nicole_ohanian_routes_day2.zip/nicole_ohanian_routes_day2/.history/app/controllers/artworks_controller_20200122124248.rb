class ArtworksController < ApplicationController

    
end