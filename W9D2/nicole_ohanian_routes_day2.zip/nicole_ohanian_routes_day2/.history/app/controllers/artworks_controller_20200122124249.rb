class ArtworksController < ApplicationController


end