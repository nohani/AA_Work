class ArtworksController < ApplicationController

    def create
    end

    def index
    end

    def destroy
    end

    def show
    end

    def update
    end

end