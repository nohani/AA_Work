class CommentsController < ApplicationController

    def create
    end

    def index
    end

    def destroy
    end
end