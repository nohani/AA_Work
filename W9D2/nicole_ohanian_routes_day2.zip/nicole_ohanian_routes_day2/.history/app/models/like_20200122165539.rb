class Like < ApplicationRecord
    
end