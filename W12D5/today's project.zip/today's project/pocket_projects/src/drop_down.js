const dogs = {
    "Corgi": "https://www.akc.org/dog-breeds/cardigan-welsh-corgi/",
    "Australian Shepherd": "https://www.akc.org/dog-breeds/australian-shepherd/",
    "Affenpinscher": "https://www.akc.org/dog-breeds/affenpinscher/",
    "American Staffordshire Terrier": "https://www.akc.org/dog-breeds/american-staffordshire-terrier/",
    "Tosa": "https://www.akc.org/dog-breeds/tosa/",
    "Labrador Retriever": "https://www.akc.org/dog-breeds/labrador-retriever/",
    "French Bulldog": "https://www.akc.org/dog-breeds/french-bulldog/"
};

export const dogLinkCreator = () => {
    const dogType = Object.keys(dogs)
    const links = Object.values(dogs)
    const completedLinks = [];

    for (let i = 0; i < dogType.length; i++) {
        const tagName = document.createElement('a');
        tagName.innerHTML = dogType[i];
        tagName.href = links[i];
        const li = document.createElement('li');
        li.className = 'dog-link';
        li.appendChild(tagName);
        completedLinks.push(li);
    }
    return completedLinks;
}

export const attachDogLinks = () => {
    const dogLinks = dogLinkCreator();
    const rootEl = document.querySelector(".drop-down-dog-list");
    dogLinks.forEach((link) => {
        rootEl.appendChild(link);
    })
}

export const handleEnter = (event) => {
    let dog = document.querySelectorAll('.dog-link');

    dog.forEach((ele) => {
        ele.classList.add('enter');
    })
}

export const handleLeave = (event) => {
    const dog = document.querySelectorAll('.dog-link');

    dog.forEach((ele) => {
        ele.classList.remove('enter');
    })
}

attachDogLinks();
const rootEl = document.querySelector('.drop-down-dog-nav');

rootEl.addEventListener('mouseenter', handleEnter);
rootEl.addEventListener('mouseleave', handleLeave);