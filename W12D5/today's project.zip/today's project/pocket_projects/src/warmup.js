const partyHeader = document.getElementById('party');

export const htmlGenerator = (string, htmlElement) => {
    if (htmlElement.hasChildNodes()) {
        let array = Array.from(htmlElement.childNodes);
        array.forEach((node) => {
            htmlElement.removeChild(node);
        })
    }
    const input = document.createElement('p');
    input.textContent = string;
    htmlElement.appendChild(input);
};

htmlGenerator("I <3 Vanilla DOM manipulation.", partyHeader);