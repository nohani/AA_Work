class User < ApplicationRecord
  
end