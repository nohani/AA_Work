class UsersController < ApplicationController
  def index

  end
end