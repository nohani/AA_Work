class CreateArtworks < ActiveRecord::Migration[5.2]
  def change
    create_table :artworks do |t|
    end
  end
end
