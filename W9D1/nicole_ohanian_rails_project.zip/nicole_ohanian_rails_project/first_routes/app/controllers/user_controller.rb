class UsersController < ApplicationController

end