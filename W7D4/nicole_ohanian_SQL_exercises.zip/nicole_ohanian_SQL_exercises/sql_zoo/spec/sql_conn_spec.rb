require 'rspec'
require 'sqlzoo'

describe 'tests the DB connection' do
    it 'selects the population of Germany' do
      
    end
end